OK_FORMAT = True

test = {   'name': 'q1_2_3_1_1',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> # Fill in the line\n>>> #   num_avenues_away = ...\n>>> # in the cell above. \n>>> num_avenues_away != ...\nTrue', 'hidden': False, 'locked': False},
                                   {   'code': '>>> # Remember to compute the absolute value of 7-10.  Traveling \n>>> # "-3 blocks" doesn\'t really make sense!\n>>> num_avenues_away != -3\nTrue',
                                       'hidden': False,
                                       'locked': False},
                                   {'code': '>>> num_avenues_away\n3', 'hidden': False, 'locked': False},
                                   {'code': '>>> manhattan_distance\n1462', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
