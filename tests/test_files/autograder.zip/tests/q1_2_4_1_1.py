OK_FORMAT = True

test = {   'name': 'q1_2_4_1_1',
    'points': None,
    'suites': [{'cases': [{'code': '>>> round(min_length_difference, 5)\n3.9', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
