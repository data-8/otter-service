test = {   'name': 'q41',
    'points': None,
    'suites': [{'cases': [{'code': '>>> round(botan_distance_from_average_m, 5) == 0.162\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
