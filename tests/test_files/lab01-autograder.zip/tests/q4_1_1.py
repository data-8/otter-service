test = {   'name': 'q4_1_1',
    'points': None,
    'suites': [{'cases': [{'code': '>>> round(min_height_difference, 5) == 0.05\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
